
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

def smooth(arr):
    smoothing_rate = 0.7
    temp_arr = np.zeros(len(arr))
    temp_arr[0] = arr[0]
    for i in range(1, len(arr)):
        temp_arr[i] = smoothing_rate * temp_arr[i-1] + (1-smoothing_rate) * arr[i]
    return temp_arr

if __name__=="__main__":
    x1 = np.loadtxt("agent_UAV.txt")
    x2 = np.loadtxt("agent_UAV_clip_change.txt")

    x1 = smooth(x1)
    x2 = smooth(x2)

    iter = range(10000)
    sns.set(style="whitegrid", font_scale=1.1)
    sns.tsplot(time=iter, data = x1, color = "r",linestyle='-',condition="PPO")
    sns.tsplot(time=iter, data = x2, color = "b",linestyle='-.',condition="PPO with dynamic clip")

    plt.ticklabel_format(axis='y',style='sci',scilimits=(0,4))
    plt.ylabel("Reward", fontsize=15)
    plt.xlabel("Iteration Number", fontsize=15)
    plt.savefig("clip_reward.pdf", format='pdf')
    plt.show()